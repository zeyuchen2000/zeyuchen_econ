The current folder contains STATA do-files that were used for obtaining the results of the paper "Window dressing: Changes in atmospheric pollution at boundaries in response to regional environmental policy in China," by Liyuan Cui, Zeyu Chen, Yanfen Huang, and Huayi Yu. 

STATA log files and output figures are also provided.