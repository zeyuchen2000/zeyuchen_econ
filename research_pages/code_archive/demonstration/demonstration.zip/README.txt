
Folder Structure
- raw/ folder: Contains all raw datasets (e.g., patent data, listed firm data, and business registration data).
- build.ipynb: A Python notebook that processes raw data and constructs analysis-ready datasets, saved in the build/ folder.
- figures_and_tables.ipynb: A Python notebook that generates figures in the paper. Output figures are stored in figures/ folder.
- script.do: A Stata do-file that performs econometric analysis using processed datasets from build/ folder.

Notes
- Data Removal: Since this project is still ongoing, I have to exclude the raw and processed datasets from the code sample.
- Language Note: Some data and code annotations are in Chinese, as the original sources use Chinese characters. I apologize for any inconvenience this may cause.