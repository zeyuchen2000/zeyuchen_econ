This file contains replication of the paper by Caliendo and Parro (2015) tilted "Estimates of the Trade and Welfare Effects of NAFTA." Their codes can be download from the paper webpage from RES: https://doi.org/10.1093/restud/rdu035. 

I replicate their Matlab codes from two folders, "Counterfactuals" and "Equilibrium", using Python. See files "Equilibrium.ipynb" and "Counterfactuals.ipynb"